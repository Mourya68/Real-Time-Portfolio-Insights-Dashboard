infer_schema!("mysql://username:password@host.com/dbname");
