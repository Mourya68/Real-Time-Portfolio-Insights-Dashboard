//! Example configuration.  Copy to `conf.js` before running.

const INTERNAL_API_URL = 'http://localhost:7878';

export { INTERNAL_API_URL };
