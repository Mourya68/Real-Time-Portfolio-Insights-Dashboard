module.exports = {
  mysqlHost: "example.com",
  mysqlUsername: "username",
  mysqlPassword: "password",
  mysqlDatabase: "database",
};
